char	*Instruments[] ={"Grand Piano\0",\
						"Bright Acoustic Piano\0",\
						"Electric Grand Piano\0",\
						"Honky-tonk Piano\0",\
						"Rhodes Piano\0",\
						"Chorused Piano\0",\
						"Harpsichord\0",\
						"Clavinet\0",\
						"Celesta\0",\
						"Glockensipiel\0",\
						"Music Box\0",\
						"Vibraphone\0",\
						"Marimba\0",\
						"Xylophone\0",\
						"Tubular Bells\0",\
						"Dulcimer\0",\
						"Hammond Organ\0",\
						"Percussive Organ\0",\
						"Rock Organ\0",\
						"Church Organ\0",\
						"Reed Organ\0",\
						"Accordion\0",\
						"Harmonica\0",\
						"Tango Accordion\0",\
						"Acoustic Guitar (nylon)\0",\
						"Acoustic Guitar (steel)\0",\
						"Electric Guitar (jazz)\0",\
						"Electric Guitar (clean)\0",\
						"Electric Guitar (muted)\0",\
						"Overdriven Guitar\0",\
						"Distotion Guitar\0",\
						"Guitar Harmonics\0",\
						"Acoustic Bass\0",\
						"Electric Bass (finger)\0",\
						"Electric Bass (pick)\0",\
						"Fretless Bass\0",\
						"Slap Bass 1\0",\
						"Slap Bass 2\0",\
						"Synth Bass 1\0",\
						"Synth Bass 2\0",\
						"Violin\0",\
						"Viola\0",\
						"Cello\0",\
						"Contrabass\0",\
						"Tremolo Strings\0",\
						"Pizzicato Strings\0",\
						"Orchestral Harp\0",\
						"Timpani\0",\
						"String Ensemble 1\0",\
						"String Ensemble 2\0",\
						"SynthStrings 1\0",\
						"SynthStrings 2\0",\
						"Choir Aahs\0",\
						"Voice Oohs\0",\
						"Synth Voice\0",\
						"Orchestra Hit\0",\
						"Trumpet\0",\
						"Trombone\0",\
						"Tuba\0",\
						"Muted Trumpet\0",\
						"French Horn\0",\
						"Brass Section\0",\
						"Synth Brass 1\0",\
						"Synth Brass 2\0",\
						"Soprano Sax\0",\
						"Alto Sax\0",\
						"Tenor Sax\0",\
						"Baritone Sax\0",\
						"Oboe\0",\
						"English Horn\0",\
						"Bassoon\0",\
						"Clarinet\0",\
						"Piccolo\0",\
						"Flute\0",\
						"Recorder\0",\
						"PanFlute\0",\
						"Bottle Blow\0",\
						"Shakuhachi\0",\
						"Whistle\0",\
						"Ocarina\0",\
						"Lead 1 (square)\0",\
						"Lead 2 (sawtooth)\0",\
						"Lead 3 (caliope lead)\0",\
						"Lead 4 (chiff lead)\0",\
						"Lead 5 (charang)\0",\
						"Lead 6 (voice)\0",\
						"Lead 7 (fifths)\0",\
						"Lead 8 (brass+lead)\0",\
						"Pad 1 (new age)\0",\
						"Pad 2 (warm)\0",\
						"Pad 3 (polysynth)\0",\
						"Pad 4 (choir)\0",\
						"Pad 5 (bowed)\0",\
						"Pad 6 (metallic)\0",\
						"Pad 7 (halo)\0",\
						"Pad 8 (sweep)\0",\
						"FX 1 (rain)\0",\
						"FX 2 (soundtrack)\0",\
						"FX 3 (crystal)\0",\
						"FX 4 (atmosphere)\0",\
						"FX 5 (brightness)\0",\
						"FX 6 (goblins)\0",\
						"FX 7 (echoes)\0",\
						"FX 8 (sci-fi)\0",\
						"Sitar\0",\
						"Banjo\0",\
						"Shamisen\0",\
						"Koto\0",\
						"Kalimba\0",\
						"Badpipe\0",\
						"Fiddle\0",\
						"Shanai\0",\
						"Tinkle Bell\0",\
						"Agogo\0",\
						"Steel Drums\0",\
						"Woodblock\0",\
						"Taiko Drum\0",\
						"Melodic Tom\0",\
						"Synth Drum\0",\
						"Reverse Cymbal\0",\
						"Guitar Fret Noise\0",\
						"Breath Noise\0",\
						"Seashore\0",\
						"Bird Tweet\0",\
						"Telephone Ring\0",\
						"Helicopter\0",\
						"Applause\0",\
						"Gunshot\0",
						"\0\0"};